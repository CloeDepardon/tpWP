<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '0000' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '[/^NAd5`K.Ew8}?k~=RujuRFlSL0K:Ti3UyKv$>B[a}X+GK`:YmW]2/bu<GbzLT0' );
define( 'SECURE_AUTH_KEY',  'OopdPv$zk^chlo==LS4aUu78ac7)7F>D8GW2b*LRm6~V0eVdg_YW6x*hg=9,z4!,' );
define( 'LOGGED_IN_KEY',    '5lr?Q,-9M)XHn[/z42FEDAn(a&ho*X^:5U0r4N%}}u1ll(/qZ^iU6)?[ ?]})peL' );
define( 'NONCE_KEY',        'Mc%jtTuNPg#9uPz >?o.#VQ{)L,qmdBzF+F+x-^<.g&{jT&0#l_d:Xw Hk;E}sC_' );
define( 'AUTH_SALT',        '+tJe@^NmwocE/hWFtN78Z@<-P9X>msR/TX=_J47.|=7cZxUN3isL^]O^;,ppEd<?' );
define( 'SECURE_AUTH_SALT', '?KsJ*-;q${.2o?+t*H<<=1,lX[h~0x%p@Nec0.0 _e{2w+->Q@~LNo=&Y{@$|iwI' );
define( 'LOGGED_IN_SALT',   ' FhN7g5TV`uOZf6 `=~2T]K{O)MpHb=D,n+(nA+x/S(wvN2EGdXKIouK*>Cj^jHk' );
define( 'NONCE_SALT',       '~#2l2dWIkG9MF{@`r8>5r!QM/Oz%&{3}F7.<{GCX<LORZdz.)]3OwYTQ B3w^5^$' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
